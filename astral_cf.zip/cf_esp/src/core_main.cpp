// cf_core: root, read-only memory reader + optional aim assist (virtual touch). Talks to the overlay APK over stdin/stdout.
// usage: cf_core [-p <pkg substring>] [--base 0x<libil2cpp base>]
// out:  S|ok|cx,cy,cz|fx,fy,fz|fov|localTeam|actor,team,hp,flags,x,y,z,vx,vy,vz,name;...   (flags: 1 local, 2 dead, 4 crouch)
//       N|status      (the S line may carry an 8th field: aim diagnostics)
// in:   C|aim=1,key=1,mode=0,fov=180,smooth=0.25,ppd=9,maxstep=40,bone=0,invy=0,sx=0.62,sy=0.4,W=2400,H=1080,rot=1,fs=1,fh=0,team=1,maxd=150,lead=60
#include "aim.h"
#include "authtok.h"
#include "inject.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <linux/input.h>
#include <mutex>
#include <string>
#include <thread>
#include <csignal>
#include <unistd.h>

static std::mutex g_mu;
static volatile bool g_quit = false;
static void on_signal(int) { g_quit = true; }
static AimCfg g_cfg;
static volatile bool g_tokenOk = false;   // set once by a "K|hwid|dayEpoch|tokenHex" line from the Java side

static void apply_kv(AimCfg& c, const std::string& k, float v) {
    if (k == "aim") c.on = v != 0; else if (k == "key") c.key = (int)v; else if (k == "fov") c.fovPx = v;
    else if (k == "smooth") c.smooth = v; else if (k == "ppd") c.ppd = v; else if (k == "maxstep") c.maxStep = v;
    else if (k == "bone") c.bone = (int)v; else if (k == "invy") c.invY = v != 0; else if (k == "sx") c.sx = v;
    else if (k == "sy") c.sy = v; else if (k == "W") c.W = v; else if (k == "H") c.H = v; else if (k == "rot") c.rot = (int)v;
    else if (k == "fs") c.fovScale = v; else if (k == "fh") c.fovHoriz = v != 0; else if (k == "team") c.teamCheck = v != 0;
    else if (k == "maxd") c.maxDist = v; else if (k == "lead") c.leadMs = v; else if (k == "mode") c.mode = (int)v;
    else if (k == "norecoil") c.noRecoil = v != 0; else if (k == "nospread") c.noSpread = v != 0;
    else if (k == "bhop") c.mv.bhop = v != 0; else if (k == "noclip") c.mv.noclip = v != 0;
    else if (k == "speed") c.mv.speed = v; else if (k == "jump") c.mv.jump = v; else if (k == "grav") c.mv.grav = v;
    else if (k == "bhopspeed") c.mv.bhopSpeed = v; else if (k == "fly") c.mv.fly = v != 0; else if (k == "flyspeed") c.mv.flySpeed = v;
    else if (k == "skey") c.silentKey = (int)v;
    else if (k == "trig") c.trig = v != 0; else if (k == "trigpx") c.trigPx = v; else if (k == "trigms") c.trigMs = v;
    else if (k == "fx") c.fireX = v; else if (k == "fy") c.fireY = v;
    else if (k == "silent") c.silent = v != 0; else if (k == "silentfov") c.silentFov = v;
    else if (k == "stamina") c.mv.infStamina = v != 0; else if (k == "nofall") c.mv.noFall = v != 0; else if (k == "noslow") c.mv.noWeaponSlow = v != 0;
    else if (k == "airstrafe") c.mv.airStrafe = v;
    else if (k == "infammo") c.infAmmo = v != 0; else if (k == "wallbang") c.wallbang = v != 0;
    else if (k == "cam3p") c.cam3p = v != 0; else if (k == "cam3pdist") c.cam3pDist = v; else if (k == "cam3pheight") c.cam3pHeight = v;
    else if (k == "ice") c.mv.ice = v != 0; else if (k == "nocrouchslow") c.mv.noCrouchSlow = v != 0;
    else if (k == "nosway") c.noSway = v != 0; else if (k == "noscope") c.noScope = v != 0; else if (k == "noscopefov") c.noScopeFov = v;
    else if (k == "rage") c.rage = v != 0; else if (k == "ragepriority") c.ragePriority = (int)v;
    else if (k == "ragebonefallback") c.rageBoneFallback = v != 0; else if (k == "rageheadonly") c.rageHeadOnly = v != 0;
    else if (k == "rageinstant") c.rageInstant = v != 0; else if (k == "rageignorefov") c.rageIgnoreFov = v != 0;
    else if (k == "ragenohysteresis") c.rageNoHysteresis = v != 0; else if (k == "rageautofire") c.rageAutoFire = v != 0;
    else if (k == "ragetrigpx") c.rageTrigPx = v; else if (k == "ragetrigms") c.rageTrigMs = v;
}

static void stdin_loop() {
    char line[1024];
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'K' && line[1] == '|') {
            char buf[1024];
            strncpy(buf, line + 2, sizeof buf - 1); buf[sizeof buf - 1] = 0;
            char* save = nullptr;
            char* hwid = strtok_r(buf, "|\r\n", &save);
            char* day  = strtok_r(nullptr, "|\r\n", &save);
            char* tok  = strtok_r(nullptr, "|\r\n", &save);
            if (hwid && day && tok && authtok_verify(hwid, day, tok)) g_tokenOk = true;
            continue;
        }
        if (line[0] != 'C' || line[1] != '|') continue;
        AimCfg c;
        { std::lock_guard<std::mutex> l(g_mu); c = g_cfg; }
        char* save = nullptr;
        for (char* t = strtok_r(line + 2, ",\r\n", &save); t; t = strtok_r(nullptr, ",\r\n", &save)) {
            char* eq = strchr(t, '=');
            if (!eq) continue;
            *eq = 0;
            apply_kv(c, t, strtof(eq + 1, nullptr));
        }
        std::lock_guard<std::mutex> l(g_mu);
        g_cfg = c;
    }
    g_quit = true;                               // parent (APK) closed our stdin -> main loop restores the game's code and exits
}

static std::string clean(const char* s) {
    std::string o;
    for (; *s; s++) o.push_back((isalnum((unsigned char)*s) || *s == '_' || *s == '.' || *s == '-' || *s == ' ') ? *s : '_');
    return o;
}

int main(int argc, char** argv) {
    std::string pkg = "counterflame";
    uint64_t baseOverride = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-p") && i + 1 < argc) pkg = argv[++i];
        else if (!strcmp(argv[i], "--base") && i + 1 < argc) baseOverride = strtoull(argv[++i], nullptr, 16);
    }
    if (getuid() != 0) { printf("N|needs root\n"); return 1; }
    setvbuf(stdout, nullptr, _IOLBF, 0);
    signal(SIGTERM, on_signal); signal(SIGINT, on_signal); signal(SIGHUP, on_signal); signal(SIGPIPE, SIG_IGN);
    std::thread(stdin_loop).detach();

    // wait a few seconds for the app's token line; no token, no game access. fails quiet on
    // purpose -- a cracked/standalone binary just sits here printing nothing useful, no banner.
    {
        auto t0 = std::chrono::steady_clock::now();
        while (!g_tokenOk && !g_quit && std::chrono::steady_clock::now() - t0 < std::chrono::seconds(5))
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        if (!g_tokenOk) return 0;
    }

    Proc proc;
    Game* game = nullptr;
    Snapshot snap;
    Touch touch;
    Keys keys;
    bool touchOk = touch.init(), keysOk = keys.init();   // touch.init() may take 0.5 s (uinput device creation)
    std::string status = "waiting for game";
    int sticky = 0, silentSticky = 0;
    float fx = 0, fy = 0;                          // virtual finger position (px)
    AimCtl ctl;
    double lastStep = 0, trigSince = 0, trigLast = 0;
    bool trigOn = false;
    int lockActor = 0;
    char info[480] = {0};
    auto lastTry = std::chrono::steady_clock::now() - std::chrono::seconds(10);

    for (;;) {
        if (g_quit) { if (game) game->shutdown_patches(); touch.lift(0); touch.lift(1); return 0; }
        if (game && !proc.alive()) { delete game; game = nullptr; proc.detach(); status = "game closed"; touch.lift(0); touch.lift(1); }
        if (!game && std::chrono::steady_clock::now() - lastTry > std::chrono::seconds(2)) {
            lastTry = std::chrono::steady_clock::now();
            int pid = Proc::find_pid(pkg);
            if (pid) {
                proc.attach(pid);
                uint64_t base = baseOverride ? baseOverride : proc.module_base("libil2cpp.so");
                if (base) game = new Game(proc, base);
                else { proc.detach(); status = "libil2cpp.so not mapped (use --base)"; }
            }
        }
        if (!game) { printf("N|%s\n", status.c_str()); std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }
        if (!game->update(snap)) { touch.lift(0); touch.lift(1); trigOn = false; printf("N|%s\n", game->status()); std::this_thread::sleep_for(std::chrono::milliseconds(100)); continue; }

        std::string out = "S|ok|";
        char b[320];
        snprintf(b, sizeof b, "%.3f,%.3f,%.3f|%.4f,%.4f,%.4f|%.2f|%d|", snap.cam.pos.x, snap.cam.pos.y, snap.cam.pos.z,
                 snap.cam.fwd.x, snap.cam.fwd.y, snap.cam.fwd.z, snap.cam.fovY, (int)snap.localTeam);
        out += b;
        bool first = true;
        for (auto& p : snap.players) {
            snprintf(b, sizeof b, "%s%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,", first ? "" : ";", p.actor, (int)p.team, p.hp,
                     (p.local ? 1 : 0) | (p.dead ? 2 : 0) | (p.crouch ? 4 : 0) | (p.mate ? 8 : 0), p.pos.x, p.pos.y, p.pos.z, p.vel.x, p.vel.y, p.vel.z);
            out += b; out += clean(p.name);
            first = false;
        }
        AimCfg c;
        { std::lock_guard<std::mutex> l(g_mu); c = g_cfg; }
        const float R2D = 57.29578f;
        float camYaw = std::atan2(snap.cam.fwd.x, snap.cam.fwd.z) * R2D;
        float camPit = std::asin(std::max(-1.f, std::min(1.f, snap.cam.fwd.y))) * R2D;
        int withTeam = 0, mates = 0;
        for (auto& p : snap.players) { if (p.team) withTeam++; if (p.mate) mates++; }
        snprintf(info, sizeof info, "touch=%s lock=%d ppd=%.1f/%.1f life=%d lt=%d teams=%d/%d mates=%d wp=%d/%d cp=%d sil=%s/%u cam3p=%s ; %s ; %s ; %s", touch.mode(), lockActor, ctl.ppdX, ctl.ppdY,
                 snap.lifeOk ? 1 : 0, (int)snap.localTeam, withTeam, (int)snap.players.size(), mates, game->patched(), game->weapons(), game->code_patched(),
                 game->silent_status(), (unsigned)game->silent_hits(), game->cam3p_status(), game->local_diag().c_str(), game->move_diag().c_str(), game->arms_diag().c_str());
        out += "|"; out += info;
        snprintf(b, sizeof b, "|%d,%d,%.2f,%.2f,%.2f,%.1f,%d\n", snap.bomb.state, snap.bomb.hasPos ? 1 : 0, snap.bomb.pos.x, snap.bomb.pos.y, snap.bomb.pos.z, snap.bomb.remaining, snap.bomb.owner);
        out += b;
        if (fputs(out.c_str(), stdout) < 0) return 0;     // reader gone

        // weapon/arms/movement classes are offset-drifted on the current game build (verified
        // by diag mismatch: raw ptr present but class check fails) -- writing through them risks
        // garbage heap writes like the old Oxide recoil bug, so these stay off until a fresh dump.
        game->patch_scope(c.noScope, c.noScopeFov);
        game->silent_prepare(c.silent);
        game->drive_cam3p(c.cam3p, c.cam3pDist, c.cam3pHeight);

        // ---- aim assist: one correction per game frame, never per poll
        if (keysOk) { keys.poll(); keys.grab((c.on && c.key != 0) || (c.silent && c.silentKey != 0)); }
        bool armed = c.on && touchOk && (c.key == 0 || (c.key == 1 && keys.down(KEY_VOLUMEDOWN)) || (c.key == 2 && keys.down(KEY_VOLUMEUP)));
        double now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
        bool changed = ctl.observe(camYaw, camPit, touch.active());
        AimOut a = armed ? aim_step(snap, c, sticky) : AimOut();
        if (a.has) {
            sticky = a.actor; lockActor = a.actor;
            bool fresh = !touch.active();
            if (fresh || changed || now - lastStep > 0.04) {
                lastStep = now;
                if (fresh || fx < 0.05f * c.W || fx > 0.95f * c.W || fy < 0.05f * c.H || fy > 0.95f * c.H) {
                    if (touch.active()) touch.lift();   // re-seed the finger so it never drifts off the look area
                    fx = c.sx * c.W; fy = c.sy * c.H;
                    ctl.idle();
                }
                float dx, dy;
                ctl.step(a, c, now, dx, dy);
                fx += dx; fy += dy;
                touch.move(fx, fy, c.W, c.H, c.rot);
            }
        } else { sticky = 0; lockActor = 0; if (touch.active()) { touch.lift(); ctl.idle(); } }

        // ---- silent aim: the detour replaces the direction of every shot while armed and a target is inside the silent FOV
        {
            bool sArmed = c.silent && (c.silentKey == 0 || (c.silentKey == 1 && keys.down(KEY_VOLUMEDOWN)) || (c.silentKey == 2 && keys.down(KEY_VOLUMEUP)));
            bool sOn = false;
            Vec3 sdir;
            if (sArmed && snap.valid) {
                AimCfg sc = c; sc.on = true; sc.fovPx = c.silentFov;
                AimOut so = aim_step(snap, sc, silentSticky);
                if (so.has) { sOn = true; sdir = so.dir; silentSticky = so.actor; lockActor = so.actor; } else silentSticky = 0;
            } else silentSticky = 0;
            game->silent_feed(sOn, sdir);
        }

        // ---- auto fire (casual `trig`, or `rageAutoFire` with its own radius/delay while rage mode is on)
        bool onT = false;
        bool trigActive = c.trig || (c.rage && c.rageAutoFire);
        float usePx = (c.rage && c.rageAutoFire) ? c.rageTrigPx : c.trigPx;
        float useMs = (c.rage && c.rageAutoFire) ? c.rageTrigMs : c.trigMs;
        if (trigActive && touchOk && snap.valid) {
            AimCfg tc = c; tc.on = true; tc.fovPx = usePx;
            for (int b : {0, 1}) { tc.bone = b; if (aim_step(snap, tc, 0).has) { onT = true; break; } }
        }
        if (onT) {
            trigLast = now;
            if (trigSince == 0) trigSince = now;
            if (!trigOn && now - trigSince >= useMs / 1000.0) { touch.move(c.fireX * c.W, c.fireY * c.H, c.W, c.H, c.rot, 1); trigOn = true; }
        } else {
            trigSince = 0;
            if (trigOn && now - trigLast > 0.06) { touch.lift(1); trigOn = false; }
        }
        if (!trigActive && trigOn) { touch.lift(1); trigOn = false; }

        std::this_thread::sleep_for(std::chrono::milliseconds(4));
    }
}
