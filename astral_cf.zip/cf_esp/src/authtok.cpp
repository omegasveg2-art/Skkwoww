#include "authtok.h"
#include <cstdint>
#include <cstring>
#include <cstdio>

// ---- compact public-domain-style SHA-256 (single translation unit, no deps) ----
namespace {

struct Sha256 {
    uint32_t h[8];
    uint64_t len = 0;
    uint8_t buf[64];
    size_t bufLen = 0;

    Sha256() {
        static const uint32_t iv[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
        memcpy(h, iv, sizeof h);
    }

    static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

    void block(const uint8_t* p) {
        static const uint32_t k[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        uint32_t w[64];
        for (int i = 0; i < 16; i++)
            w[i] = (uint32_t(p[i*4]) << 24) | (uint32_t(p[i*4+1]) << 16) | (uint32_t(p[i*4+2]) << 8) | uint32_t(p[i*4+3]);
        for (int i = 16; i < 64; i++) {
            uint32_t s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >> 3);
            uint32_t s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for (int i = 0; i < 64; i++) {
            uint32_t S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
            uint32_t ch = (e & f) ^ (~e & g);
            uint32_t t1 = hh + S1 + ch + k[i] + w[i];
            uint32_t S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + maj;
            hh=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
    }

    void update(const uint8_t* data, size_t n) {
        len += n;
        while (n) {
            size_t take = 64 - bufLen; if (take > n) take = n;
            memcpy(buf + bufLen, data, take);
            bufLen += take; data += take; n -= take;
            if (bufLen == 64) { block(buf); bufLen = 0; }
        }
    }

    void finish(uint8_t out[32]) {
        uint64_t bitLen = len * 8;
        uint8_t pad = 0x80;
        update(&pad, 1);
        uint8_t zero = 0;
        while (bufLen != 56) update(&zero, 1);
        uint8_t lenBytes[8];
        for (int i = 0; i < 8; i++) lenBytes[i] = (uint8_t)(bitLen >> (56 - 8*i));
        update(lenBytes, 8);
        for (int i = 0; i < 8; i++) {
            out[i*4]   = (uint8_t)(h[i] >> 24);
            out[i*4+1] = (uint8_t)(h[i] >> 16);
            out[i*4+2] = (uint8_t)(h[i] >> 8);
            out[i*4+3] = (uint8_t)(h[i]);
        }
    }
};

void sha256(const uint8_t* data, size_t n, uint8_t out[32]) {
    Sha256 s; s.update(data, n); s.finish(out);
}

void hmacSha256(const uint8_t* key, size_t keyLen, const uint8_t* msg, size_t msgLen, uint8_t out[32]) {
    uint8_t k0[64] = {0};
    if (keyLen > 64) sha256(key, keyLen, k0);
    else memcpy(k0, key, keyLen);

    uint8_t ipad[64], opad[64];
    for (int i = 0; i < 64; i++) { ipad[i] = k0[i] ^ 0x36; opad[i] = k0[i] ^ 0x5c; }

    Sha256 inner; inner.update(ipad, 64); inner.update(msg, msgLen);
    uint8_t innerDigest[32]; inner.finish(innerDigest);

    Sha256 outer; outer.update(opad, 64); outer.update(innerDigest, 32);
    outer.finish(out);
}

// same split-and-XOR secret as KeyGate.java's S1/S2/MASK -- keep both in sync if you rotate it.
const uint8_t MASK = 0x5A;
const uint8_t S1[8] = {0x3a, 0x02, 0x63, 0x58, 0x7d, 0x0d, 0x60, 0x5c};
const uint8_t S2[8] = {0x29, 0x1a, 0x7b, 0x49, 0x6e, 0x12, 0x71, 0x4f};

void secret(uint8_t out[16]) {
    for (int i = 0; i < 8; i++) out[i] = S1[i] ^ MASK;
    for (int i = 0; i < 8; i++) out[8 + i] = S2[i] ^ MASK;
}

} // namespace

bool authtok_verify(const std::string& hwid, const std::string& dayEpoch, const std::string& tokenHex) {
    if (tokenHex.size() != 16) return false; // 8 bytes hex
    std::string msg = hwid + "|" + dayEpoch;
    uint8_t key[16]; secret(key);
    uint8_t digest[32];
    hmacSha256(key, sizeof key, reinterpret_cast<const uint8_t*>(msg.data()), msg.size(), digest);

    char expect[17];
    for (int i = 0; i < 8; i++) snprintf(expect + i*2, 3, "%02x", digest[i]);
    expect[16] = 0;

    // constant-time-ish compare, this isn't the part worth hardening further
    unsigned diff = 0;
    for (int i = 0; i < 16; i++) diff |= (unsigned)(expect[i] != tokenHex[i]);
    return diff == 0;
}
