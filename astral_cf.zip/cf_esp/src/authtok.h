// Verifies the "K|hwid|dayEpoch|tokenHex" line the Java side sends over stdin right after launch
// (see KeyGate.coreTokenLine in the app). Self-contained HMAC-SHA256, no OpenSSL dependency --
// this binary ships standalone to /data/local/tmp, pulling in a crypto lib isn't worth it for an
// 8-byte check.
#pragma once
#include <string>

// true if tokenHex matches HMAC-SHA256(secret, hwid + "|" + dayEpoch) truncated to 8 bytes (16 hex chars),
// same construction and secret as KeyGate.hmacHex()/secret() on the Java side.
bool authtok_verify(const std::string& hwid, const std::string& dayEpoch, const std::string& tokenHex);
