# aggressive: rename+shrink everything, keep only what Android needs to find by reflection.
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-overloadaggressively
-dontpreverify

-keep public class cf.esp.MainActivity { public <init>(); }
-keep public class cf.esp.EspService { public <init>(); }

# android.R / manifest components resolved by name, don't rename
-keepclassmembers class * extends android.app.Activity
-keepclassmembers class * extends android.app.Service

# org.json is part of the Android platform at runtime, not in our jar -- don't let R8 try to inline/verify it away
-dontwarn org.json.**

-dontwarn javax.crypto.**
