// Astral.exe license server. Cloudflare Workers (free tier) + KV (free tier: 100k reads/day, 1k writes/day).
// KV layout: key "ASTRAL-XXXX-..." -> JSON { hwid: string|null, expires_at: 0|epochDay, used: bool, created_at: epochMs }
// expires_at = 0 means lifetime key.
//
// Routes:
//   POST /check            { key, hwid }                 -> { ok, reason, expires_at }   (public, called by the app)
//   POST /admin/create     { days, count? }               -> { keys: [...] }              (needs X-Admin-Secret header)
//   POST /admin/revoke     { key }                        -> { ok }                        (needs X-Admin-Secret header)
//
// Deploy: wrangler.toml in this folder, `wrangler kv namespace create KEYS` then paste the id in,
// set the admin secret with `wrangler secret put ADMIN_SECRET`, then `wrangler deploy`.

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json" } });
}

function todayEpochDay() {
  return Math.floor(Date.now() / 86400000);
}

function randomKey() {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  let s = "";
  for (const b of bytes) s += alphabet[b % alphabet.length];
  const grouped = s.match(/.{1,4}/g).join("-");
  return "ASTRAL-" + grouped;
}

async function handleCheck(req, env) {
  let body;
  try { body = await req.json(); } catch (e) { return json({ ok: false, reason: "format" }, 400); }
  const key = (body.key || "").trim().toUpperCase();
  const hwid = (body.hwid || "").trim();
  if (!key || !hwid) return json({ ok: false, reason: "format" }, 400);

  const raw = await env.KEYS.get(key);
  if (!raw) return json({ ok: false, reason: "bad_key" }, 404);
  const rec = JSON.parse(raw);

  if (rec.expires_at !== 0 && todayEpochDay() > rec.expires_at) {
    return json({ ok: false, reason: "expired", expires_at: rec.expires_at });
  }

  if (!rec.hwid) {
    // first activation: bind this device
    rec.hwid = hwid;
    rec.used = true;
    await env.KEYS.put(key, JSON.stringify(rec));
    return json({ ok: true, reason: "ok", expires_at: rec.expires_at });
  }

  if (rec.hwid !== hwid) {
    return json({ ok: false, reason: "device_mismatch" });
  }

  return json({ ok: true, reason: "ok", expires_at: rec.expires_at });
}

function adminOk(req, env) {
  return req.headers.get("X-Admin-Secret") === env.ADMIN_SECRET;
}

async function handleCreate(req, env) {
  if (!adminOk(req, env)) return json({ error: "forbidden" }, 403);
  let body = {};
  try { body = await req.json(); } catch (e) {}
  const days = Number.isFinite(body.days) ? body.days : 30;
  const count = Math.min(Math.max(Number.isFinite(body.count) ? body.count : 1, 1), 200);
  const expiresAt = days === 0 ? 0 : todayEpochDay() + days;
  const keys = [];
  for (let i = 0; i < count; i++) {
    const k = randomKey();
    await env.KEYS.put(k, JSON.stringify({ hwid: null, expires_at: expiresAt, used: false, created_at: Date.now() }));
    keys.push(k);
  }
  return json({ keys });
}

async function handleRevoke(req, env) {
  if (!adminOk(req, env)) return json({ error: "forbidden" }, 403);
  let body = {};
  try { body = await req.json(); } catch (e) {}
  const key = (body.key || "").trim().toUpperCase();
  if (!key) return json({ error: "format" }, 400);
  await env.KEYS.delete(key);
  return json({ ok: true });
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === "POST" && url.pathname === "/check") return handleCheck(req, env);
    if (req.method === "POST" && url.pathname === "/admin/create") return handleCreate(req, env);
    if (req.method === "POST" && url.pathname === "/admin/revoke") return handleRevoke(req, env);
    return json({ error: "not found" }, 404);
  },
};
