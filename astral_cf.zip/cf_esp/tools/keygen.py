#!/usr/bin/env python3
"""Keygen for Astral.exe's offline KeyGate (android/java/cf/esp/KeyGate.java).
Secret here must match KeyGate.S1/S2/MASK exactly -- regen both sides together.

Key = base32( expiryDays:u32be | nonce:u32be | hmac_sha256(expiryDays|nonce)[:6] ), 14 bytes raw.
expiryDays = epoch day the key stops working, 0 = never expires.

Usage:
  python3 keygen.py                 # one 30-day key
  python3 keygen.py --days 365      # one 1-year key
  python3 keygen.py --days 0        # lifetime key
  python3 keygen.py --count 20 --days 30 > batch.txt
"""
import argparse
import base64
import hmac
import hashlib
import os
import struct
import time

MASK = 0x5A
S1 = bytes(b ^ MASK for b in [0x3a, 0x02, 0x63, 0x58, 0x7d, 0x0d, 0x60, 0x5c])
S2 = bytes(b ^ MASK for b in [0x29, 0x1a, 0x7b, 0x49, 0x6e, 0x12, 0x71, 0x4f])
SECRET = S1 + S2


def make_key(expire_days_from_now: int) -> str:
    expiry = 0 if expire_days_from_now == 0 else int(time.time() // 86400) + expire_days_from_now
    nonce = struct.unpack(">I", os.urandom(4))[0]
    signed = struct.pack(">II", expiry, nonce)
    mac = hmac.new(SECRET, signed, hashlib.sha256).digest()[:6]
    raw = signed + mac
    b32 = base64.b32encode(raw).decode().rstrip("=")
    grouped = "-".join(b32[i:i + 4] for i in range(0, len(b32), 4))
    return "ASTRAL-" + grouped


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=30, help="validity in days from now, 0 = lifetime")
    ap.add_argument("--count", type=int, default=1)
    args = ap.parse_args()
    for _ in range(args.count):
        print(make_key(args.days))
