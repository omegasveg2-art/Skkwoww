package cf.esp;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Base64;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Server-backed license check (Cloudflare Worker + KV, see cloudflare/worker.js) with a 24h
 * offline grace period, plus a local HMAC token so cf_core (the native side) can tell it's
 * talking to a copy of the app that already passed KeyGate, without cf_core doing any network
 * itself. None of this stops someone who patches the dex to skip the call -- it stops casual
 * key sharing and makes a crack cost more than "edit one if statement in an unprotected class".
 */
final class KeyGate {
    private static final String PREFS = "astral_lic";
    private static final long GRACE_MS = TimeUnit.HOURS.toMillis(24);
    private static final long REVALIDATE_EVERY_MS = TimeUnit.HOURS.toMillis(4);

    // FILL: your deployed worker URL (wrangler deploy prints it), e.g. https://astral-cf-keys.you.workers.dev
    private static final String SERVER_URL = "https://astral-cf-keys.example.workers.dev/check";

    // local app<->core secret, nothing to do with the server. Same XOR'd split as before --
    // keep this in sync with src/authtok.cpp's S1/S2/MASK if you ever change it.
    private static final byte MASK = (byte) 0x5A;
    private static final byte[] S1 = {0x3a, 0x02, 0x63, 0x58, 0x7d, 0x0d, 0x60, 0x5c};
    private static final byte[] S2 = {0x29, 0x1a, 0x7b, 0x49, 0x6e, 0x12, 0x71, 0x4f};

    private static byte[] secret() {
        byte[] out = new byte[S1.length + S2.length];
        for (int i = 0; i < S1.length; i++) out[i] = (byte) (S1[i] ^ MASK);
        for (int i = 0; i < S2.length; i++) out[S1.length + i] = (byte) (S2[i] ^ MASK);
        return out;
    }

    static final class Result {
        final boolean ok;
        final String reason; // "ok" | "format" | "bad_key" | "expired" | "device_mismatch" | "network"
        final long expiresAtDay;
        Result(boolean ok, String reason, long exp) { this.ok = ok; this.reason = reason; this.expiresAtDay = exp; }
    }

    interface Callback { void onResult(Result r); }

    private static SharedPreferences sp(Context ctx) { return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private static String deviceHwid(Context ctx) {
        try {
            String aid = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            return (aid == null || aid.isEmpty()) ? "no-android-id" : aid;
        } catch (Exception e) {
            return "no-android-id";
        }
    }

    private static String xor(String s) {
        byte[] secret = secret();
        byte[] in = s.getBytes();
        byte[] out = new byte[in.length];
        for (int i = 0; i < in.length; i++) out[i] = (byte) (in[i] ^ secret[i % secret.length]);
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private static String unxor(String b64) {
        try {
            byte[] in = Base64.decode(b64, Base64.NO_WRAP);
            byte[] secret = secret();
            byte[] out = new byte[in.length];
            for (int i = 0; i < in.length; i++) out[i] = (byte) (in[i] ^ secret[i % secret.length]);
            return new String(out);
        } catch (Exception e) {
            return null;
        }
    }

    // ---- cache (not plaintext: XOR'd with the local secret before it hits SharedPreferences) ----

    private static void cacheWrite(Context ctx, String key, boolean ok, long expiresAtDay) {
        sp(ctx).edit()
                .putString("k", xor(key))
                .putBoolean("ok", ok)
                .putLong("exp", expiresAtDay)
                .putLong("checked_at", System.currentTimeMillis())
                .apply();
    }

    private static String cachedKey(Context ctx) {
        String enc = sp(ctx).getString("k", null);
        return enc == null ? null : unxor(enc);
    }

    /** Pure offline check: cached key must still be marked ok, and either within the grace window
     *  or past it but still not locally expired (server re-check will catch an actually-revoked key
     *  on the next revalidate pass). Call this freely on the UI thread -- no I/O. */
    static boolean quickCheck(Context ctx) {
        SharedPreferences p = sp(ctx);
        if (cachedKey(ctx) == null) return false;
        if (!p.getBoolean("ok", false)) return false;
        long exp = p.getLong("exp", 0);
        long today = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis());
        if (exp != 0 && today > exp) return false;
        long checkedAt = p.getLong("checked_at", 0);
        // past the 24h grace with no successful re-check since: fail closed until the next revalidate succeeds
        return System.currentTimeMillis() - checkedAt < GRACE_MS;
    }

    static boolean dueForRevalidate(Context ctx) {
        long checkedAt = sp(ctx).getLong("checked_at", 0);
        return System.currentTimeMillis() - checkedAt > REVALIDATE_EVERY_MS;
    }

    private static Result callServer(Context ctx, String key) {
        HttpURLConnection c = null;
        try {
            URL u = new URL(SERVER_URL);
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            JSONObject body = new JSONObject();
            body.put("key", key);
            body.put("hwid", deviceHwid(ctx));
            byte[] out = body.toString().getBytes("UTF-8");
            try (OutputStream os = c.getOutputStream()) { os.write(out); }
            int code = c.getResponseCode();
            java.io.InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (is == null) return new Result(false, "network", 0);
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] tmp = new byte[2048]; int n;
            while ((n = is.read(tmp)) > 0) buf.write(tmp, 0, n);
            JSONObject resp = new JSONObject(buf.toString("UTF-8"));
            boolean ok = resp.optBoolean("ok", false);
            String reason = resp.optString("reason", ok ? "ok" : "bad_key");
            long exp = resp.optLong("expires_at", 0);
            return new Result(ok, reason, exp);
        } catch (Exception e) {
            return new Result(false, "network", 0);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Blocking network call -- run off the main thread. Used by the key-entry screen and by
     *  periodic background revalidation. Updates the cache unless the failure was purely network
     *  (so a dropped connection doesn't nuke an otherwise-valid cached license). */
    static Result activateOnline(Context ctx, String key) {
        String k = key == null ? "" : key.trim().toUpperCase();
        if (k.isEmpty()) return new Result(false, "format", 0);
        Result r = callServer(ctx, k);
        if (r.reason.equals("network")) return r; // leave cache alone, caller decides (grace / retry)
        cacheWrite(ctx, k, r.ok, r.expiresAtDay);
        return r;
    }

    /** Re-checks the already-cached key against the server. Call from a background thread. */
    static Result revalidate(Context ctx) {
        String k = cachedKey(ctx);
        if (k == null) return new Result(false, "format", 0);
        return activateOnline(ctx, k);
    }

    static void runAsync(Context ctx, String key, Callback cb) {
        new Thread(() -> {
            Result r = activateOnline(ctx, key);
            cb.onResult(r);
        }, "keygate-check").start();
    }

    // ---- local token for cf_core: proves "this process was launched by an app that just
    // passed quickCheck()", nothing more. Native side verifies the same HMAC (src/authtok.cpp). ----

    static String coreTokenLine(Context ctx) {
        String hwid = deviceHwid(ctx);
        long day = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis());
        String dayStr = Long.toString(day);
        String token = hmacHex(hwid + "|" + dayStr);
        return "K|" + hwid + "|" + dayStr + "|" + token + "\n";
    }

    private static String hmacHex(String msg) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(secret(), "HmacSHA256"));
            byte[] full = m.doFinal(msg.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format("%02x", full[i])); // 8 bytes is plenty, this isn't the license key itself
            return sb.toString();
        } catch (Exception e) {
            return "0000000000000000";
        }
    }

    private static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }
}
