#!/bin/sh
# builds cf_core (arm64-v8a, static PIE) from src/*.cpp using the NDK standalone clang.
# needs: ANDROID_NDK_HOME (or ANDROID_NDK_ROOT) pointing at an installed NDK.
# out: ./cf_core, picked up by build_apk.sh (copied into assets/).
set -e
: "${ANDROID_NDK_HOME:=$ANDROID_NDK_ROOT}"
[ -n "$ANDROID_NDK_HOME" ] || { echo "set ANDROID_NDK_HOME" >&2; exit 1; }

HOST=linux-x86_64
TOOLCHAIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/$HOST"
CXX="$TOOLCHAIN/bin/aarch64-linux-android26-clang++"
[ -x "$CXX" ] || { echo "no $CXX (check NDK version / host tag)" >&2; exit 1; }

"$CXX" -O2 -std=c++17 -fPIE -pie -static-libstdc++ \
  -Isrc -o cf_core \
  src/core_main.cpp src/aim.cpp src/code.cpp src/game.cpp src/il2cpp.cpp src/inject.cpp src/mem.cpp src/authtok.cpp

echo "ok -> cf_core"
