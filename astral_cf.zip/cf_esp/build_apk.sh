#!/bin/sh
# needs: ./cf_core (arm64, built with NDK), JDK, ANDROID_HOME with build-tools + a platform. out: cf_esp.apk
# optional: R8_JAR pointing at a standalone r8.jar (com.android.tools:r8 on maven) to minify with
# proguard-rules.pro; falls back to plain d8 (no shrink/obfuscate) if R8_JAR isn't set.
set -e
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
AJ=$(ls -d "$ANDROID_HOME"/platforms/android-* | sort -V | tail -1)/android.jar
rm -rf build && mkdir -p build/classes build/assets build/res-compiled
cp cf_core build/assets/cf_core
"$BT/aapt2" compile --dir android/res -o build/res-compiled
"$BT/aapt2" link -o build/base.apk -I "$AJ" --manifest android/AndroidManifest.xml \
  --min-sdk-version 26 --target-sdk-version 33 --version-code 1 --version-name 1 -A build/assets \
  -R build/res-compiled/*.flat
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp "$AJ" -d build/classes $(find android/java -name '*.java')

if [ -n "$R8_JAR" ] && [ -f proguard-rules.pro ]; then
  echo "minifying with r8"
  java -cp "$R8_JAR" com.android.tools.r8.R8 --release --min-api 26 --lib "$AJ" \
    --pg-conf proguard-rules.pro --output build $(find build/classes -name '*.class')
else
  echo "R8_JAR not set or no proguard-rules.pro -- plain d8, no shrink/obfuscate"
  "$BT/d8" --release --min-api 26 --lib "$AJ" --output build $(find build/classes -name '*.class')
fi
(cd build && zip -q base.apk classes.dex)
"$BT/zipalign" -f -p 4 build/base.apk build/aligned.apk
keytool -genkeypair -keystore build/dbg.jks -storepass android -keypass android -alias k -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=cf" >/dev/null 2>&1
"$BT/apksigner" sign --ks build/dbg.jks --ks-pass pass:android --key-pass pass:android --out cf_esp.apk build/aligned.apk
echo "ok -> cf_esp.apk"
