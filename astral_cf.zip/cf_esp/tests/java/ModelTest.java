package cf.esp;
public class ModelTest {
    public static void main(String[] a) throws Exception {
        histTest();
        Snap s = Model.parse("S|ok|0.000,1.600,0.000|0.0000,0.0000,1.0000|75.00|1|1,1,100,1,1.000,0.000,1.000,0,0,0,me;2,2,73,4,0.000,0.000,20.000,1.5,0,0,Enemy;3,1,0,2,5.000,0.000,9.000,0,0,0,Dead");
        Snap si = Model.parse("S|ok|0,1.6,0|0,0,1|75|1|1,1,100,1,1,0,1,0,0,0,me|touch=uinput lock=2 ppd=9.0/-9.0");
        check(si.ok && si.lock == 2 && si.info.startsWith("touch=uinput") && si.players.length == 1);
        check(s.ok && s.players.length == 3 && s.players[1].hp == 73 && s.players[1].crouch() && s.players[2].dead() && s.players[0].local());
        check(s.players[1].name.equals("Enemy") && s.players[1].vx == 1.5f);
        float[] o = new float[2];
        check(Model.w2s(s, 1f, 0, 1.7f, 20, 2400, 1080, o));
        System.out.println("enemy head: " + o[0] + " " + o[1] + "  (C++ test printed 1200.0 536.5)");
        check(Math.abs(o[0] - 1200f) < 0.2 && Math.abs(o[1] - 536.5f) < 0.2);
        check(Model.w2s(s, 1f, 10, 1.6f, 10, 1920, 1080, o) && o[0] > 960);          // +X is right
        check(!Model.w2s(s, 1f, 0, 1.6f, -5, 1920, 1080, o));                         // behind
        check(!Model.parse("N|waiting for game").ok && Model.parse("N|waiting for game").status.equals("waiting for game"));
        check(!Model.parse("garbage").ok && !Model.parse("S|ok|x|y|1|1|").ok);
        // effective fov
        check(Math.abs(Model.effFov(70f, 1f, false, 2f) - 70f) < 1e-4);
        check(Model.effFov(90f, 1f, true, 16f / 9f) < 60f && Model.effFov(90f, 1f, true, 16f / 9f) > 50f);  // 90 horiz @16:9 -> ~58.7 vert
        // prediction: camera turning right at 2 rad/s, repeats of the same line must not zero the rate
        Model.snap = Model.parse("S|ok|0,0,0|0,0,1|60|1|");
        Thread.sleep(20);
        Snap n = Model.parse("S|ok|0,0,0|" + Math.sin(0.04) + ",0," + Math.cos(0.04) + "|60|1|");
        Model.publish(n);
        check(Model.snap.yawRate > 0.5f);
        float r1 = Model.snap.yawRate;
        Thread.sleep(5);
        Model.publish(Model.parse("S|ok|0,0,0|" + Math.sin(0.04) + ",0," + Math.cos(0.04) + "|60|1|"));   // duplicate line
        check(Math.abs(Model.snap.yawRate - r1) < 1e-6 && Model.snap.tData == n.tData);
        float[] c = new float[6];
        Model.predictCam(Model.snap, 0.05f, c);
        check(Math.atan2(c[3], c[5]) > Model.snap.yaw);                                // predicted yaw is ahead
        // prediction removes lag: a target that was centred stays near centre when predicted with the true dt
        Snap bs = Model.parse("S|ok|0,1.6,0|0,0,1|75|1||touch=x lock=0 ; a ; b ; c|2,1,5.00,1.00,7.00,38.5,3");
        check(bs.ok && bs.bombState == 2 && bs.bombHas && Math.abs(bs.bx - 5f) < 1e-4f && Math.abs(bs.bombRem - 38.5f) < 1e-4f && bs.bombOwner == 3 && bs.lock == 0);
        Snap bn = Model.parse("S|ok|0,1.6,0|0,0,1|75|1||touch=x lock=0");
        check(bn.ok && bn.bombState == 0);
        System.out.println("java ok");
    }
    static void check(boolean b) { if (!b) throw new AssertionError(new Throwable().getStackTrace()[1].toString()); }
    static void histTest() throws Exception {
        Model.publish(Model.parse("S|ok|0,1.6,0|0,0,1|75|1|"));
        long t1 = System.nanoTime();
        Thread.sleep(40);
        Model.publish(Model.parse("S|ok|0,1.6,0|1,0,0|75|1|"));
        long t2 = System.nanoTime();
        float[] o = new float[6];
        Model.camAt(Model.snap, (t1 + t2) / 2, o);
        check(o[3] > 0.2f && o[3] < 0.95f && o[5] > 0.2f && o[5] < 0.95f);          // halfway between facing +Z and +X
        Model.camAt(Model.snap, t1 - 1_000_000_000L, o);                              // older than anything kept -> oldest sample (+Z)
        check(Math.abs(o[5] - 1f) < 1e-3f);
        Model.camAt(Model.snap, t2 + 5_000_000L, o);                                  // slightly future -> extrapolated, still sane
        check(Math.abs(o[3] * o[3] + o[4] * o[4] + o[5] * o[5] - 1f) < 1e-3f);
        System.out.println("hist ok");
    }
}
